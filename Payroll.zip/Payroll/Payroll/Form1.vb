﻿Public Class frmPayroll
    Function grossSalary(ByVal bSalary As Double) As Double
        Return bSalary + (bSalary * 0.1)
    End Function

    Function pension(ByVal bSalary As Double) As Double
        Return bSalary * 0.04
    End Function

    Function deduction(ByVal bSalary As Double) As Double
        Return bSalary * 0.02
    End Function

    Function tax(ByVal bSalary As Double) As Double
        Dim taxRate As Double
        If bSalary > 0 And bSalary <= 600 Then
            taxRate = bSalary * 0
        ElseIf bSalary > 600 And bSalary <= 1650 Then
            taxRate = bSalary * 0.1
        ElseIf bSalary > 1650 And bSalary <= 3200 Then
            taxRate = bSalary * 0.15
        ElseIf bSalary > 3200 And bSalary <= 5250 Then
            taxRate = bSalary * 0.2
        ElseIf bSalary > 5250 And bSalary <= 7800 Then
            taxRate = bSalary * 0.25
        ElseIf bSalary > 7800 And bSalary <= 10900 Then
            taxRate = bSalary * 0.3
        ElseIf bSalary > 10900 Then
            taxRate = bSalary * 0.35
        Else
            MsgBox("Invalid input", vbCritical)
        End If
        Return taxRate
    End Function

    Function netSalary(ByVal gSalary As Double, ByVal pension As Double, ByVal deduction As Double, ByVal tax As Double) As Double
        Return gSalary - pension - deduction - tax
    End Function
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim bSalary As Double
        bSalary = Val(txtBSalary.Text)
        txtPension.Text = pension(bSalary)
        txtDeduction.Text = deduction(bSalary)
        txtTax.Text = tax(grossSalary(bSalary))
        txtGrossSalary.Text = grossSalary(bSalary)
        txtNetSalary.Text = netSalary(grossSalary(bSalary), pension(bSalary), deduction(bSalary), tax(bSalary))
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtBSalary.Clear()
        txtDeduction.Clear()
        txtGrossSalary.Clear()
        txtGrossSalary.Clear()
        txtGrossSalary.Clear()
        txtGrossSalary.Clear()
        txtGrossSalary.Clear()
        txtGrossSalary.Clear()
        txtPension.Clear()
        txtNetSalary.Clear()
        txtTax.Clear()
        txtBSalary.Select()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class